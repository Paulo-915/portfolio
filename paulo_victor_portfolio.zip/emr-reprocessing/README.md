# 🔁 EMR Reprocessing

Este projeto contém três funções Lambda que automatizam o processo de reprocessamento de dados em clusters EMR, utilizando eventos do S3 e SQS, com monitoramento via Athena e notificações por webhook.

## 📦 Estrutura

- `lambda_1_verifica_status_cluster`: Verifica se o cluster EMR está ativo e decide se deve iniciar ou adicionar um step.
- `lambda_4_submete_etapa_reproc`: Submete comandos Spark Submit ao EMR e registra o reprocessamento no Athena.
- `lambda_5_notifica_resultado`: Envia notificações formatadas via webhook e atualiza o status no Athena.

## 🧠 Arquitetura

Fluxo simplificado:
1. Evento S3 → Lambda 1 → Verifica status do cluster
2. Lambda 1 → SQS → Lambda 4 → Submete etapa no EMR
3. EMR → Evento → Lambda 5 → Atualiza Athena + Notifica via Webhook

## ⚙️ Pré-requisitos

- AWS EMR configurado com permissões para execução de steps.
- Buckets S3 com scripts e arquivos de parâmetros.
- Tabelas de monitoramento no Athena.
- Filas SQS para orquestração.
- Webhook configurado para envio de mensagens.

## 🚀 Como usar

1. Configure as variáveis de ambiente nas funções Lambda.
2. Faça upload de um JSON com os parâmetros no S3.
3. A função Lambda 1 será acionada automaticamente.
4. O fluxo seguirá conforme o status do cluster.

## ✨ Destaques técnicos

- Uso de `boto3` para integração com EMR, S3, Athena e SQS.
- Monitoramento detalhado com logs e tratamento de erros.
- Atualização dinâmica de tabelas no Athena.
- Notificações com emojis e links para o console AWS.
